import 'package:dsw_527/views/login/login_view.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    title: 'Navigation Basics',
    home: LoginView(),
  ));
}



