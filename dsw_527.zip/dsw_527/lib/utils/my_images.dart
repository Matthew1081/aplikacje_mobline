class MyImages {
  static const _assetsFolder= 'assets/images';
  static const logo = '$_assetsFolder/logo.png';
}