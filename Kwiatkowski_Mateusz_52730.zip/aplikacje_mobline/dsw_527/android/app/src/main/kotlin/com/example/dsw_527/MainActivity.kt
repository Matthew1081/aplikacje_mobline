package com.example.dsw_527

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
