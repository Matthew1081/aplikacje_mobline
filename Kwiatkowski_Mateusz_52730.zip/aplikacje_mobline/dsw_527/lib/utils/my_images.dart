class MyImages {
  static const _assetsFolder= 'assets/images';
  static const logo = '$_assetsFolder/logo.png';
  static const person = '$_assetsFolder/person.png';
  static const lock = '$_assetsFolder/lock.png';
  static const mail = '$_assetsFolder/mail.png';
  static const back = '$_assetsFolder/back.png';
  static const logo_bg = '$_assetsFolder/logo_bg.png';
}